﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quản_lý_sinh_viên_trong_kí_túc_xá.SinhVien
{
    internal class NoiQuy
    {
    }
}

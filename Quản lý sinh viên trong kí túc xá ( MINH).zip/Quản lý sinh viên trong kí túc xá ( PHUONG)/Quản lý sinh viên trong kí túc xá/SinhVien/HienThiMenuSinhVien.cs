﻿using System;
using AccountManagement;
using StudentInformation;
using RoomRegistrationStudent;
using RoomManagementSystem;
using ThongBao;
namespace DisplayStudentMenu
{
    public static class StudentMenu
    {
        public static void ShowMenu()
        {
            Student student = StudentManager.GetStudentInfo(AccountManager.CurrentUsername);
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Menu sinh viên:");
                Console.WriteLine("1. Nội quy");
                Console.WriteLine("2. Thông tin sinh viên");
                Console.WriteLine("3. Đăng ký phòng");
                Console.WriteLine("4. Kiểm tra hóa đơn đóng tiền ở");
                Console.WriteLine("5. Kiểm tra thông báo");
                Console.WriteLine("6. Đóng tiền ở ký túc xá");
                Console.WriteLine("7. Đóng tiền điện nước");
                Console.WriteLine("8. Kiểm tra hóa đơn điện nước");
                Console.WriteLine("9. Đăng xuất");
                Console.Write("Chọn chức năng: ");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập số từ 1 đến 6.");
                    Console.ReadKey();
                    continue;
                }

                switch (choice)
                {
                    case 1:
                       
                        break;
                    case 2:
                         StudentManager.ShowMenu();
                        break;
                    case 3:
                        Console.WriteLine("Đăng ký phòng...");
                        RoomOperations roomOperations = new RoomOperations();
                        roomOperations.LoadRoomsFromFile();  // Nạp danh sách phòng từ file

                        // Gọi phương thức đăng ký phòng, truyền đối tượng roomOperations vào
                        RoomRegistrationMenu.ShowRoomRegistrationMenu(roomOperations); 
                        Console.ReadKey();  // Đợi người dùng nhấn phím để tiếp tục
                        break;
                    case 4:
                        ReadBillAndNotification.ReadStudentAccommodationBill(student.StudentID);
                        Console.ReadKey();
                        break;
                    case 5:
                        ReadBillAndNotification.ReadStudentNotification(student.StudentID);
                        Console.ReadKey();
                        break;
                    case 6:
                        NotificationSystem.CreateAccommodationRequest(student.FullName, student.StudentID);
                        Console.WriteLine("Yêu cầu thanh toán tiền ở của bạn đã được gửi. Vui lòng chờ quản lý xuất hóa đơn.");
                        Console.ReadKey();
                        break;
                    case 7:
                        Console.Write("Nhập số phòng: ");
                        string roomNumber = Console.ReadLine();
                        NotificationSystem.CreateLivingExpenseRequest(student.FullName, student.StudentID, roomNumber);
                        Console.WriteLine($"Yêu cầu thanh toán điện nước ở của phòng {roomNumber} đã được gửi. Vui lòng chờ quản lý xuất hóa đơn.");
                        Console.ReadKey();
                        break;
                    case 8:
                        Console.Write("Nhập số phòng: ");
                        string roomNumber2 = Console.ReadLine();
                        ReadBillAndNotification.ReadStudentLivingExpenseBill(roomNumber2);
                        Console.ReadKey();
                        break;
                    case 9:
                        return;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ.");
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}



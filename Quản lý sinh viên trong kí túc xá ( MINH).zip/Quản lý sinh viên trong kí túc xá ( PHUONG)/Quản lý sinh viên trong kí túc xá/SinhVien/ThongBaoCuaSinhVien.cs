﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ThongBao
{
    public static class ReadBillAndNotification
    {
        public static void ReadStudentAccommodationBill(string studentId)
        {
            string baseDirectory = "BillStorage/Accommodation";
            string fileName = $"hoadontieno_{studentId}.txt";
            string filePath = Path.Combine(baseDirectory, fileName);
            if (File.Exists(filePath))
            {
                try
                {
                    // Đọc dữ liệu từ file
                    string[] lines = File.ReadAllLines(filePath);

                    foreach (var line in lines)
                    {
                        Console.WriteLine(line);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Có lỗi xảy ra khi đọc file:");
                    Console.WriteLine(ex.Message);
                }
            }
            else
            {
                Console.WriteLine($"Không tìm thấy file hoadontieno_{studentId}.txt trong thư mục {baseDirectory}.");
            }
        }

        public static void ReadStudentLivingExpenseBill(string roomNumber)
        {
            string baseDirectory = "BillStorage/LivingExpense";
            string fileName = $"hoadondiennuoc_{roomNumber}.txt";
            string filePath = Path.Combine(baseDirectory, fileName);
            if (File.Exists(filePath))
            {
                try
                {
                    // Đọc dữ liệu từ file
                    string[] lines = File.ReadAllLines(filePath);

                    foreach (var line in lines)
                    {
                        Console.WriteLine(line);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Có lỗi xảy ra khi đọc file:");
                    Console.WriteLine(ex.Message);
                }
            }
            else
            {
                Console.WriteLine($"Không tìm thấy file hoadondiennuoc_{roomNumber}.txt trong thư mục {baseDirectory}.");
            }
        }

        public static void ReadStudentNotification(string studentId)
        {
            string baseDirectory = "StudentNotification";
            string fileName = $"Notification_{studentId}.txt";
            string filePath = Path.Combine(baseDirectory, fileName);
            if (File.Exists(filePath))
            {
                try
                {
                    // Đọc dữ liệu từ file
                    string[] lines = File.ReadAllLines(filePath);

                    foreach (var line in lines)
                    {
                        Console.WriteLine(line);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Có lỗi xảy ra khi đọc file:");
                    Console.WriteLine(ex.Message);
                }
            }
            else
            {
                Console.WriteLine($"Không tìm thấy file hoadontieno_{studentId}.txt trong thư mục {baseDirectory}.");
            }
        }
    }

    public static class NotificationSystem
    {
        private const string NOTIFICATION_FILE = "Notifications.txt";

        public static void CreateRegistrationRequest(string studentName, string studentId, string roomNumber)
        {
            string notification = $"REGISTRATION,{DateTime.Now:yyyy-MM-dd HH:mm:ss},{studentName},{studentId},{roomNumber}";
            File.AppendAllLines(NOTIFICATION_FILE, new[] { notification });
        }

        public static void CreateTransferRequest(string studentName, string studentId, string fromRoom, string toRoom, string reason)
        {
            string notification = $"TRANSFER,{DateTime.Now:yyyy-MM-dd HH:mm:ss},{studentName},{studentId},{fromRoom},{toRoom},{reason}";
            File.AppendAllLines(NOTIFICATION_FILE, new[] { notification });
        }

        public static void CreateAccommodationRequest(string studentName, string studentId)
        {
            string notification = $"ACCOMMODATION,{DateTime.Now:yyyy-MM-dd HH:mm:ss},{studentName},{studentId}";
            File.AppendAllLines(NOTIFICATION_FILE, new[] { notification });
        }

        public static void CreateLivingExpenseRequest(string studentName, string studentId, string roomNumber)
        {
            string notification = $"LIVINGEXPENSE,{DateTime.Now:yyyy-MM-dd HH:mm:ss},{studentName},{studentId},{roomNumber}";
            File.AppendAllLines(NOTIFICATION_FILE, new[] { notification });
        }

        public static List<string> GetPendingRequests()
        {
            if (!File.Exists(NOTIFICATION_FILE))
            {
                return new List<string>();
            }
            return File.ReadAllLines(NOTIFICATION_FILE).ToList();
        }

        public static void RemoveRequest(string request)
        {
            var requests = GetPendingRequests();
            requests.Remove(request);
            File.WriteAllLines(NOTIFICATION_FILE, requests);
        }
    }
}
﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using AccountManagement;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace StudentInformation
{
    public class Student
    {
        public string Username { get; set; }
        public string StudentID { get; set; }
        public string FullName { get; set; }
        public string Hometown { get; set; }
        public string PhoneNumber { get; set; }
        public string Faculty { get; set; }
        public string Class { get; set; }


        public override string ToString()
        {
            return $"{Username},{StudentID},{FullName},{Hometown},{PhoneNumber},{Faculty},{Class}";
        }
    }

    public static class StudentManager
    {
        private static readonly string studentFile = "StudentInformation.txt";

        public static void ShowMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("==== THÔNG TIN SINH VIÊN ====");
                Console.WriteLine("[1] Xem thông tin cá nhân");
                Console.WriteLine("[2] Cập nhật thông tin cá nhân");
                Console.WriteLine("[3] Quay lại");
                Console.Write("Chọn chức năng: ");

                switch (Console.ReadLine())
                {
                    case "1":
                        ViewInformation();
                        break;
                    case "2":
                        UpdateInformation(AccountManager.CurrentUsername);
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ!");
                        Console.ReadKey();
                        break;
                }
            }
        }

        public static bool HasInformation(string username)
        {
            if (!File.Exists(studentFile)) return false;

            try
            {
                return File.ReadLines(studentFile)
                    .Skip(1)
                    .Any(line => line.Split(',')[0] == username);
            }
            catch
            {
                return false;
            }
        }

        public static void ViewInformation()
        {
            Console.Clear();
            Console.WriteLine("==== THÔNG TIN SINH VIÊN ====");

            var student = GetStudentInfo(AccountManager.CurrentUsername);
            if (student != null)
            {
                Console.WriteLine($"Mã số sinh viên: {student.StudentID}");
                Console.WriteLine($"Họ tên: {student.FullName}");
                Console.WriteLine($"Quê quán: {student.Hometown}");
                Console.WriteLine($"Số điện thoại: {student.PhoneNumber}");
                Console.WriteLine($"Khoa: {student.Faculty}");
                Console.WriteLine($"Lớp: {student.Class}");
            }
            else 
            { 
                Console.WriteLine("Không tìm thấy thông tin sinh viên.");
            }

            Console.WriteLine("\nNhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }

        public static void UpdateInformation(string username)
        {
            try
            {
                var student = new Student { Username = username };

                Console.Write("Nhập mã số sinh viên: ");
                student.StudentID = Console.ReadLine();

                Console.Write("Nhập họ tên: ");
                student.FullName = GetValidInput("Họ tên không được để trống.");

                Console.Write("Nhập quê quán: ");
                student.Hometown = GetValidInput("Quê quán không được để trống.");

                do
                {
                    Console.Write("Nhập số điện thoại (10 chữ số): ");
                    student.PhoneNumber = Console.ReadLine();
                }
                while (!Regex.IsMatch(student.PhoneNumber, @"^\d{10}$"));

                Console.Write("Nhập khoa: ");
                student.Faculty = GetValidInput("Khoa không được để trống.");

                Console.Write("Nhập lớp: ");
                student.Class = GetValidInput("Lớp không được để trống.");

                SaveStudentInfo(student);

                Console.WriteLine("Cập nhật thông tin thành công!");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi: {ex.Message}");
                Console.ReadKey();
            }
        }

        private static string GetValidInput(string errorMessage)
        {
            string input;
            do
            {
                input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine(errorMessage);
                }
            }
            while (string.IsNullOrWhiteSpace(input));
            return input;
        }

        public static Student GetStudentInfo(string username)
        {
            if (!File.Exists(studentFile)) return null;

            try
            {
                var lines = File.ReadAllLines(studentFile);
                var studentLine = lines.Skip(1)
                    .FirstOrDefault(line => line.Split(',')[0] == username);

                if (studentLine == null) return null;

                var parts = studentLine.Split(',');
                return new Student
                {
                    Username = parts[0],
                    StudentID = parts[1],
                    FullName = parts[2],
                    Hometown = parts[3],
                    PhoneNumber = parts[4],
                    Faculty = parts[5],
                    Class = parts[6]
                };
            }
            catch
            {
                return null;
            }
        }

        private static void SaveStudentInfo(Student student)
        {
            try
            {
                var lines = File.Exists(studentFile)
                    ? File.ReadAllLines(studentFile).ToList()
                    : new List<string> { "Username,StudentID,FullName,Hometown,PhoneNumber,Faculty,Class" };

                var existingIndex = lines.FindIndex(l => l.Split(',')[0] == student.Username);
                if (existingIndex > 0)
                {
                    lines[existingIndex] = student.ToString();
                }
                else
                {
                    lines.Add(student.ToString());
                }

                File.WriteAllLines(studentFile, lines);
            }
            catch (Exception ex)
            {
                throw new Exception($"Không thể lưu thông tin sinh viên: {ex.Message}");
            }
        }

        
    }

}
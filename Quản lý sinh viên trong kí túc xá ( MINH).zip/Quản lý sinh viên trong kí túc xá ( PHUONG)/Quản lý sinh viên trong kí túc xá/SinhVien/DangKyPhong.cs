﻿using RoomManagementSystem;
using System;
using System.IO;
using System.Linq;
using StudentInformation;
using System.Collections.Generic;
using AccountManagement;
using ThongBao;
namespace RoomRegistrationStudent
{ 
    public static class RoomRegistrationMenu
    {
        public static void ShowRoomRegistrationMenu(RoomOperations roomOperations)
        {
            Student student = StudentManager.GetStudentInfo(AccountManager.CurrentUsername);
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=====Menu Đăng Ký Phòng=====");
                Console.WriteLine("1. Hiển thị danh sách phòng");
                Console.WriteLine("2. Đăng ký phòng");
                Console.WriteLine("3. Yêu cầu chuyển phòng");
                Console.WriteLine("4. Quay lại");
                Console.Write("Chọn chức năng: ");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập số từ 1 đến 4.");
                    Console.ReadKey();
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        roomOperations.DisplayRoomList();// Hiển thị danh sách phòng
                        Console.ReadKey();
                        break;
                    case 2:
                        RoomManagement roomManagement = new RoomManagement();
                        if (roomManagement.IsStudentInAnyRoom(student.StudentID))
                        {
                            Console.WriteLine("Bạn đã có phòng. Vui lòng chọn chức năng khác.");
                            Console.ReadKey();
                            break;
                        }
                        Console.Write("Nhập phòng muốn đăng ký: ");
                        string numberRoom = Console.ReadLine();
                        NotificationSystem.CreateRegistrationRequest(student.FullName, student.StudentID, numberRoom);
                        Console.WriteLine("Yêu cầu đăng ký phòng đã được gửi. Vui lòng chờ quản lý phê duyệt.");
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Write("Nhập số phòng hiện tại: ");
                        string fromRoom = Console.ReadLine();
                        Console.Write("Nhập số phòng muốn chuyển: ");
                        string toRoom = Console.ReadLine();
                        Console.Write("Nhập lý do chuyển phòng: ");
                        string reason = Console.ReadLine();
                        NotificationSystem.CreateTransferRequest(student.FullName, student.StudentID, fromRoom, toRoom, reason);
                        Console.WriteLine("Yêu cầu chuyển phòng đã được gửi. Vui lòng chờ quản lý phê duyệt.");
                        Console.ReadKey();
                        break;
                    case 4:
                        return; // Quay lại menu trước
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ.");
                        break;
                }
            }
        }
    }
}

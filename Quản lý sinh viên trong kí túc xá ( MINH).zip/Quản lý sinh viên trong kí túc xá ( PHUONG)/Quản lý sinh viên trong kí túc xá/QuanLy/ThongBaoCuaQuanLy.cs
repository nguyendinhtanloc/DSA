﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using RoomRegistrationStudent;
using RoomManagementSystem;
using ThongBao;
using BillManagement;
namespace DormitoryManagementSystem
{
    public class ManagerMenu
    {
        private static RoomManagement roomManager = new RoomManagement();
        private const string NOTIFICATION_OF_ALL_STUDENTS = "StudentNotification";

        public ManagerMenu()
        {
            InitializeStudentRoomsFolder();
        }

        private void InitializeStudentRoomsFolder()
        {
            if (!Directory.Exists(NOTIFICATION_OF_ALL_STUDENTS))
            {
                Directory.CreateDirectory(NOTIFICATION_OF_ALL_STUDENTS);
            }
        }

        public static void ShowMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== MENU QUẢN LÝ KÝ TÚC XÁ ===");
                Console.WriteLine("1. Xem yêu cầu đăng ký/chuyển phòng/đóng tiền ở/đóng tiền điện nước");
                Console.WriteLine("2. Xem thông tin phòng");
                Console.WriteLine("3. Quay lại");
                Console.Write("Chọn chức năng: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            ProcessRequests();
                            break;
                        case 2:
                            ViewRoomInfo();
                            break;
                        case 3:
                            return;
                        default:
                            Console.WriteLine("Lựa chọn không hợp lệ!");
                            break;
                    }
                }

                Console.WriteLine("\nNhấn phím bất kỳ để tiếp tục...");
                Console.ReadKey();
            }
        }

        private static void ProcessRequests()
        {
            var requests = NotificationSystem.GetPendingRequests();
            if (!requests.Any())
            {
                Console.WriteLine("Không có yêu cầu nào đang chờ xử lý!");
                return;
            }

            foreach (var request in requests)
            {
                var parts = request.Split(',');
                if (parts[0] == "REGISTRATION")
                {
                    ProcessRegistrationRequest(parts);
                }
                else if (parts[0] == "TRANSFER")
                {
                    ProcessTransferRequest(parts);
                }
                else if (parts[0] == "ACCOMMODATION")
                {
                    ProcessAccommodationRequest(parts);
                }
                else if (parts[0] == "LIVINGEXPENSE")
                {
                    ProcessLivingExpenseRequest(parts);
                }
            }
        }
        // Phan hoi yeu cau dang ky phong
        private static void SendNotificationOfDKP(string studentId, string content)
        {
            string fileName = Path.Combine(NOTIFICATION_OF_ALL_STUDENTS, $"Notification_{studentId}.txt");
            try
            {
                string notificationWithTimestamp = $"{DateTime.Now}: {content}";
                File.AppendAllText(fileName, notificationWithTimestamp + Environment.NewLine, Encoding.UTF8);
                Console.WriteLine($"Đã gửi thông báo cho sinh viên {studentId}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi lưu hóa đơn: {ex.Message}");
            }
        }

        private static void ProcessRegistrationRequest(string[] parts)
        {
            string studentName = parts[2];
            string studentId = parts[3];
            string roomNumber = parts[4];
            RoomOperations roomOperations = new RoomOperations();
            roomOperations.LoadRoomsFromFile();
            roomOperations.DisplayRoomList();

            Console.WriteLine($"\nYêu cầu đăng ký phòng:");
            Console.WriteLine($"Sinh viên: {studentName} ({studentId})");
            Console.WriteLine($"Phòng: {roomNumber}");

            Console.Write("Duyệt yêu cầu? (Y/N): ");
            string response = Console.ReadLine()?.ToUpper();

            if (response == "Y")
            {
                if (roomManager.RegisterStudent(roomNumber, studentName, studentId))
                {
                    NotificationSystem.RemoveRequest(string.Join(",", parts));
                    SendNotificationOfDKP(studentId, $"Đăng ký phòng {roomNumber} được duyệt.");
                    Console.WriteLine($"Đã duyệt đăng ký phòng {roomNumber} cho sinh viên {studentName}");
                }
                else
                {
                    SendNotificationOfDKP(studentId, $"Đăng ký phòng {roomNumber} không được duyệt. Phòng đã đầy hoặc bạn đã có phòng.");
                    Console.WriteLine($"Từ chối đăng ký phòng {roomNumber} cho sinh viên {studentName}");
                }
            }
            else
            {
                SendNotificationOfDKP(studentId, $"Đăng ký phòng {roomNumber} bị từ chối.");
                Console.WriteLine($"Từ chối yêu cầu đăng ký phòng {roomNumber}");
            }
        }
        //Phan hoi yeu cau chuyen phong
        private static void SendNotificationOfCP(string studentId, string content)
        {
            string fileName = Path.Combine(NOTIFICATION_OF_ALL_STUDENTS, $"Notification_{studentId}.txt");
            try
            {
                string notificationWithTimestamp = $"{DateTime.Now}: {content}";
                File.AppendAllText(fileName, notificationWithTimestamp + Environment.NewLine, Encoding.UTF8);
                Console.WriteLine($"Đã gửi thông báo cho sinh viên {studentId}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi lưu hóa đơn: {ex.Message}");
            }
        }

        private static void ProcessTransferRequest(string[] parts)
        {
            string studentName = parts[2];
            string studentId = parts[3];
            string fromRoom = parts[4];
            string toRoom = parts[5];
            string reason = parts[6];
            RoomOperations roomOperations = new RoomOperations();
            roomOperations.LoadRoomsFromFile();
            roomOperations.DisplayRoomList();

            Console.WriteLine($"\nYêu cầu chuyển phòng:");
            Console.WriteLine($"Sinh viên: {studentName} ({studentId})");
            Console.WriteLine($"Từ phòng: {fromRoom} -> {toRoom}");
            Console.WriteLine($"Lý do: {reason}");

            Console.Write("Duyệt yêu cầu? (Y/N): ");
            string response = Console.ReadLine()?.ToUpper();

            if (response == "Y")
            {
                if (roomManager.TransferStudent(fromRoom, toRoom, studentId))
                {
                    NotificationSystem.RemoveRequest(string.Join(",", parts));
                    SendNotificationOfCP(studentId, $"Chuyển từ phòng {fromRoom} đến phòng {toRoom} được duyệt.");
                    Console.WriteLine($"Đã duyệt chuyển phòng đến {toRoom} cho sinh viên {studentName}");
                }
                else
                {
                    SendNotificationOfCP(studentId, $"Chuyển từ phòng {fromRoom} đến phòng {toRoom} không được duyệt. Phòng đã đầy hoặc bạn đã có phòng.");
                    Console.WriteLine($"Từ chối chuyển phòng đến {toRoom} cho sinh viên {studentName}");
                }
            }
            else
            {
                SendNotificationOfDKP(studentId, $"Chuyển đến phòng {toRoom} bị từ chối.");
                Console.WriteLine($"Từ chối yêu cầu chuyển phòng đến {toRoom} của sinh viên {studentName}");
            }
        }

        private static void ProcessAccommodationRequest(string[] parts)
        {
            string studentName = parts[2];
            string studentId = parts[3];

            Console.WriteLine($"\nYêu cầu thanh toán tiền ở:");
            Console.WriteLine($"Sinh viên: {studentName}");
            Console.WriteLine($"MSSV: {studentId}");

            Console.Write("Duyệt yêu cầu? (Y/N): ");
            string response = Console.ReadLine()?.ToUpper();

            if (response == "Y")
            {
                string basePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "BillStorage");
                BillManagementUI ui = new BillManagementUI(basePath);
                ui.ShowMainMenu();
                NotificationSystem.RemoveRequest(string.Join(",", parts));
            }
        }

        private static void ProcessLivingExpenseRequest(string[] parts)
        {
            string studentName = parts[2];
            string studentId = parts[3];
            string roomNumber = parts[4];

            Console.WriteLine($"\nYêu cầu thanh toán điện nước:");
            Console.WriteLine($"Sinh viên: {studentName}");
            Console.WriteLine($"MSSV: {studentId}");
            Console.WriteLine($"Số phòng: {roomNumber}");

            Console.Write("Duyệt yêu cầu? (Y/N): ");
            string response = Console.ReadLine()?.ToUpper();

            if (response == "Y")
            {
                string basePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "BillStorage");
                BillManagementUI ui = new BillManagementUI(basePath);
                ui.ShowMainMenu();
                NotificationSystem.RemoveRequest(string.Join(",", parts));
            }
        }

        private static void ViewRoomInfo()
        {
            Console.Write("Nhập số phòng cần xem: ");
            string roomNumber = Console.ReadLine();
            roomManager.DisplayRoomStatus(roomNumber);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;

namespace BillManagement
{
    public class Node<T>
    {
        internal T data;
        internal Node<T> next;

        public Node(T value)
        {
            data = value;
            next = null;
        }
    }
    public class CustomQueue<T>
    {
        private Node<T> _front;
        private Node<T> _rear;
        private int _size;

        public int Count => _size;
        public bool IsEmpty() => _front == null;

        public void EnQueue(T item)
        {
            Node<T> newNode = new Node<T>(item);
            if (_rear == null)
            {
                _front = _rear = newNode;
            }
            else
            {
                _rear.next = newNode;
                _rear = newNode;
            }
            _size++;
        }

        public T DeQueue()
        {
            if (_front == null)
                throw new InvalidOperationException("Queue is empty!");

            T item = _front.data;
            _front = _front.next;
            _size--;

            if (_front == null)
                _rear = null;

            return item;
        }
    }

    public abstract class BaseBill
    {
        public bool IsPaid { get; set; }
        public DateTime CreatedDate { get; set; }

        protected BaseBill()
        {
            IsPaid = false;
            CreatedDate = DateTime.Now;
        }

        public abstract decimal CalculateTotal();
    }

    public class LivingExpenseBill : BaseBill
    {
        public string RoomNumber { get; set; }
        public decimal ElectricityBill { get; set; }
        public decimal WaterBill { get; set; }
        public decimal ServiceFee { get; set; }

        public LivingExpenseBill(string roomNumber, decimal electricityBill, decimal waterBill, decimal serviceFee)
        {
            RoomNumber = roomNumber;
            ElectricityBill = electricityBill;
            WaterBill = waterBill;
            ServiceFee = serviceFee;
        }

        public override decimal CalculateTotal()
        {
            return ElectricityBill + WaterBill + ServiceFee;
        }
    }

    public class AccommodationBill : BaseBill
    {
        public string StudentName { get; set; }
        public string StudentID { get; set; }
        public decimal AccommodationFee { get; set; }

        public AccommodationBill(string studentName, string studentID, decimal accommodationFee)
        {
            StudentName = studentName;
            StudentID = studentID;
            AccommodationFee = accommodationFee;
        }

        public override decimal CalculateTotal()
        {
            return AccommodationFee;
        }
    }

    public class BillManager
    {
        private CustomQueue<LivingExpenseBill> _livingExpenseQueue;
        private CustomQueue<AccommodationBill> _accommodationQueue;
        private string _basePath;
        private string LivingExpenseFile => Path.Combine(_basePath, "hoadondiennuoc.txt");
        private string AccommodationFile => Path.Combine(_basePath, "hoadontieno.txt");
        private const string RoomFilePath = "Room.txt";
        private const string StudentFilePath = "StudentInformation.txt";

        public BillManager(string basePath)
        {
            _livingExpenseQueue = new CustomQueue<LivingExpenseBill>();
            _accommodationQueue = new CustomQueue<AccommodationBill>();
            _basePath = basePath;
            LoadExistingBills();
            InitializeDirectories();
        }

        private void InitializeDirectories()
        {
            var directories = new[]
            {
                "LivingExpense",
                "Accommodation"
            };

            foreach (var dir in directories)
            {
                var path = Path.Combine(_basePath, dir);
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
            }
        }

        private void LoadExistingBills()
        {
            LoadLivingExpenseBills(Path.Combine(_basePath, LivingExpenseFile));
            LoadAccommodationBills(Path.Combine(_basePath, AccommodationFile));
        }

        public void LoadLivingExpenseBills(string filePath)
        {
            _livingExpenseQueue = new CustomQueue<LivingExpenseBill>();

            if (!File.Exists(filePath))
            {
                Console.WriteLine($"Không tìm thấy file: {filePath}");
                return;
            }

            try
            {
                var lines = File.ReadAllLines(filePath);

                foreach (var line in lines)
                {
                    var trimmedLine = line.Trim();
                    if (string.IsNullOrEmpty(trimmedLine)) continue;

                    var parts = trimmedLine.Split(',');

                    if (parts.Length == 4
                        && !string.IsNullOrWhiteSpace(parts[0])
                        && decimal.TryParse(parts[1], out decimal electricity)
                        && decimal.TryParse(parts[2], out decimal water)
                        && decimal.TryParse(parts[3], out decimal service))
                    {
                        var bill = new LivingExpenseBill(
                            parts[0].Trim(),
                            electricity,
                            water,
                            service
                        );
                        _livingExpenseQueue.EnQueue(bill);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi đọc file hóa đơn điện nước: {ex.Message}");
            }
        }

        public void LoadAccommodationBills(string filePath)
        {
            _accommodationQueue = new CustomQueue<AccommodationBill>();

            if (!File.Exists(filePath))
            {
                Console.WriteLine($"Không tìm thấy file: {filePath}");
                return;
            }

            try
            {
                var lines = File.ReadAllLines(filePath);

                foreach (var line in lines)
                {
                    var trimmedLine = line.Trim();
                    if (string.IsNullOrEmpty(trimmedLine)) continue;

                    var parts = trimmedLine.Split(',');

                    if (parts.Length == 3
                        && !string.IsNullOrWhiteSpace(parts[0])
                        && !string.IsNullOrWhiteSpace(parts[1])
                        && decimal.TryParse(parts[2], out decimal fee))
                    {
                        var bill = new AccommodationBill(
                            parts[0].Trim(),
                            parts[1].Trim(),
                            fee
                        );
                        _accommodationQueue.EnQueue(bill);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi đọc file hóa đơn tiền ở: {ex.Message}");
            }
        }

        public void ProcessLivingExpensePayment(string roomNumber)
        {
            var count = _livingExpenseQueue.Count;
            var updatedBills = new CustomQueue<LivingExpenseBill>();

            for (int i = 0; i < count; i++)
            {
                var bill = _livingExpenseQueue.DeQueue();
                if (bill.RoomNumber == roomNumber && !bill.IsPaid)
                {
                    bill.IsPaid = true;
                    Console.WriteLine($"Xử lý thanh toán hóa đơn cho phòng {roomNumber}");
                    PrintLivingExpenseBill(bill);
                }
                else
                {
                    updatedBills.EnQueue(bill);
                }
            }

            _livingExpenseQueue = updatedBills;
            SaveLivingExpenseBillsToFile();
        }

        public void ProcessAccommodationPayment(string studentId)
        {
            var count = _accommodationQueue.Count;
            var updatedBills = new CustomQueue<AccommodationBill>();

            for (int i = 0; i < count; i++)
            {
                var bill = _accommodationQueue.DeQueue();
                if (bill.StudentID == studentId && !bill.IsPaid)
                {
                    bill.IsPaid = true;
                    Console.WriteLine($"Xử lý thanh toán hóa đơn cho học sinh {bill.StudentName}");
                    PrintAccommodationBill(bill);
                }
                else
                {
                    updatedBills.EnQueue(bill);
                }
            }

            _accommodationQueue = updatedBills;
            SaveAccommodationBillsToFile();
        }

        // Save Living Expense Bills to file
        private void SaveLivingExpenseBillsToFile()
        {
            string filePath = Path.Combine(_basePath, LivingExpenseFile);
            var billStrings = new List<string>();

            var count = _livingExpenseQueue.Count;
            for (int i = 0; i < count; i++)
            {
                var bill = _livingExpenseQueue.DeQueue();
                billStrings.Add($"{bill.RoomNumber},{bill.ElectricityBill},{bill.WaterBill},{bill.ServiceFee}");
                _livingExpenseQueue.EnQueue(bill);
            }

            File.WriteAllLines(filePath, billStrings);
        }

        // Save Accommodation Bills to file
        private void SaveAccommodationBillsToFile()
        {
            string filePath = Path.Combine(_basePath, AccommodationFile);
            var billStrings = new List<string>();

            var count = _accommodationQueue.Count;
            for (int i = 0; i < count; i++)
            {
                var bill = _accommodationQueue.DeQueue();
                billStrings.Add($"{bill.StudentName},{bill.StudentID},{bill.AccommodationFee}");
                _accommodationQueue.EnQueue(bill);
            }

            File.WriteAllLines(filePath, billStrings);
        }

        private void SaveLivingExpenseBillToFile(LivingExpenseBill bill, string content)
        {
            string fileName = Path.Combine(_basePath, "LivingExpense", $"hoadondiennuoc_{bill.RoomNumber}.txt");
            try
            {
                File.AppendAllText(fileName, content + Environment.NewLine, Encoding.UTF8);
                Console.WriteLine($"Hóa đơn đã được lưu tại: {fileName}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi lưu hóa đơn: {ex.Message}");
            }
        }

        private void SaveAccommodationBillToFile(AccommodationBill bill, string content)
        {
            string fileName = Path.Combine(_basePath, "Accommodation", $"hoadontieno_{bill.StudentID}.txt");
            try
            {
                File.AppendAllText(fileName, content + Environment.NewLine, Encoding.UTF8);
                Console.WriteLine($"Hóa đơn đã được lưu tại: {fileName}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi lưu hóa đơn: {ex.Message}");
            }
        }
        public void PrintAccommodationBill(AccommodationBill bill)
        {
            StringBuilder billContent = new StringBuilder();
            string separator = new string('-', 50);

            billContent.AppendLine(separator);
            billContent.AppendLine("            HÓA ĐƠN TIỀN Ở KÝ TÚC XÁ");
            billContent.AppendLine($"                  {DateTime.Now:dd/MM/yyyy HH:mm}");
            billContent.AppendLine(separator);
            billContent.AppendLine("THÔNG TIN SINH VIÊN:");
            billContent.AppendLine($"Họ và tên: {bill.StudentName}");
            billContent.AppendLine($"MSSV: {bill.StudentID}");
            billContent.AppendLine(separator);
            billContent.AppendLine("CHI TIẾT HÓA ĐƠN:");
            billContent.AppendLine($"Tiền ở KTX:           {bill.AccommodationFee,15:N0} VNĐ");
            billContent.AppendLine(separator);
            billContent.AppendLine($"Tổng tiền:            {bill.CalculateTotal(),15:N0} VNĐ");
            billContent.AppendLine(separator);
            billContent.AppendLine($"Trạng thái: {(bill.IsPaid ? "Đã thanh toán" : "Chưa thanh toán")}");
            billContent.AppendLine(separator);

            Console.WriteLine(billContent.ToString());

            SaveAccommodationBillToFile(bill, billContent.ToString());
        }

        public void PrintLivingExpenseBill(LivingExpenseBill bill)
        {
            StringBuilder billContent = new StringBuilder();
            string separator = new string('-', 50);

            billContent.AppendLine(separator);
            billContent.AppendLine("            HÓA ĐƠN ĐIỆN NƯỚC KÝ TÚC XÁ");
            billContent.AppendLine($"                  {DateTime.Now:dd/MM/yyyy HH:mm}");
            billContent.AppendLine(separator);
            billContent.AppendLine($"Phòng: {bill.RoomNumber}");
            billContent.AppendLine(separator);
            billContent.AppendLine("CHI TIẾT HÓA ĐƠN:");
            billContent.AppendLine($"1. Tiền điện:          {bill.ElectricityBill,15:N0} VNĐ");
            billContent.AppendLine($"2. Tiền nước:          {bill.WaterBill,15:N0} VNĐ");
            billContent.AppendLine($"3. Phí dịch vụ:        {bill.ServiceFee,15:N0} VNĐ");
            billContent.AppendLine(separator);
            billContent.AppendLine($"Tổng tiền:             {bill.CalculateTotal(),15:N0} VNĐ");
            billContent.AppendLine(separator);
            billContent.AppendLine($"Trạng thái: {(bill.IsPaid ? "Đã thanh toán" : "Chưa thanh toán")}");
            billContent.AppendLine("Lưu ý: Vui lòng thanh toán trước ngày 20 hàng tháng.");
            billContent.AppendLine(separator);

            Console.WriteLine(billContent.ToString());

            SaveLivingExpenseBillToFile(bill, billContent.ToString());
        }

        public void GenerateUnpaidBillsReport()
        {
            Console.WriteLine("\n=== Unpaid Living Expense Bills ===");
            var leCount = _livingExpenseQueue.Count;
            for (int i = 0; i < leCount; i++)
            {
                var bill = _livingExpenseQueue.DeQueue();
                if (!bill.IsPaid)
                    PrintBillDetails(bill);
                _livingExpenseQueue.EnQueue(bill);
            }

            Console.WriteLine("\n=== Unpaid Accommodation Bills ===");
            var acCount = _accommodationQueue.Count;
            for (int i = 0; i < acCount; i++)
            {
                var bill = _accommodationQueue.DeQueue();
                if (!bill.IsPaid)
                    PrintBillDetails(bill);
                _accommodationQueue.EnQueue(bill);
            }
        }

        private void PrintBillDetails(BaseBill bill)
        {
            if (bill is LivingExpenseBill leBill)
            {
                Console.WriteLine($"Room {leBill.RoomNumber}: {leBill.CalculateTotal():C}");
            }
            else if (bill is AccommodationBill acBill)
            {
                Console.WriteLine($"Student {acBill.StudentName} ({acBill.StudentID}): {acBill.CalculateTotal():C}");
            }
        }

        public void UpdateBills()
        {
            try
            {
                var existingLivingExpenseRooms = GetExistingLivingExpenseRooms();
                var existingAccommodationStudents = GetExistingAccommodationStudents();

                var allRooms = File.ReadAllLines(RoomFilePath);
                var allStudents = File.ReadAllLines(StudentFilePath);

                allRooms = allRooms.Skip(1).ToArray();
                allStudents = allStudents.Skip(1).ToArray();

                foreach (var roomLine in allRooms)
                {
                    var roomParts = roomLine.Split(',');
                    if (roomParts.Length > 0)
                    {
                        var roomNumber = roomParts[0].Trim();
                        if (!existingLivingExpenseRooms.Contains(roomNumber))
                        {
                            var newBill = new LivingExpenseBill(
                                roomNumber,
                                0, 0, 0
                            );
                            _livingExpenseQueue.EnQueue(newBill);
                        }
                    }
                }

                foreach (var studentLine in allStudents)
                {
                    var studentParts = studentLine.Split(',');
                    if (studentParts.Length >= 3)
                    {
                        var studentName = studentParts[2].Trim();
                        var studentId = studentParts[1].Trim();

                        if (!existingAccommodationStudents.Contains(studentId))
                        {
                            var newBill = new AccommodationBill(
                                studentName,
                                studentId,
                                0
                            );
                            _accommodationQueue.EnQueue(newBill);
                        }
                    }
                }

                SaveLivingExpenseBillsToFile();
                SaveAccommodationBillsToFile();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error generating missing bills: {ex.Message}");
            }
        }

        private List<string> GetExistingLivingExpenseRooms()
        {
            var existingRooms = new List<string>();
            var count = _livingExpenseQueue.Count;
            for (int i = 0; i < count; i++)
            {
                var bill = _livingExpenseQueue.DeQueue();
                existingRooms.Add(bill.RoomNumber);
                _livingExpenseQueue.EnQueue(bill);
            }
            return existingRooms;
        }

        private List<string> GetExistingAccommodationStudents()
        {
            var existingStudents = new List<string>();
            var count = _accommodationQueue.Count;
            for (int i = 0; i < count; i++)
            {
                var bill = _accommodationQueue.DeQueue();
                existingStudents.Add(bill.StudentID);
                _accommodationQueue.EnQueue(bill);
            }
            return existingStudents;
        }
    }

    public class BillManagementUI
    {
        private BillManager _billManager;

        public BillManagementUI(string basePath)
        {
            _billManager = new BillManager(basePath);
        }

        public void ShowMainMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== HỆ THỐNG QUẢN LÝ HÓA ĐƠN ===");
                Console.WriteLine("1. Xử lý hóa đơn chi phí sinh hoạt");
                Console.WriteLine("2. Xử lý hóa đơn tiền ở");
                Console.WriteLine("3. Tạo báo cáo hóa đơn chưa thanh toán");
                Console.WriteLine("4. Cập nhật hết tất cả dữ liệu");
                Console.WriteLine("6. Thoát");
                Console.Write("\nChọn chức năng: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            ProcessLivingExpenseBill();
                            break;
                        case 2:
                            ProcessAccommodationBill();
                            break;
                        case 3:
                            _billManager.GenerateUnpaidBillsReport();
                            break;
                        case 4:
                            _billManager.UpdateBills();
                            break;
                        case 6:
                            return;
                        default:
                            Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập lại. ");
                            break;
                    }
                }

                Console.WriteLine("\nPress any key to continue...");
                Console.ReadKey();
            }
        }

        private void ProcessLivingExpenseBill()
        {
            Console.Write("Nhập số phòng: ");
            var roomNumber = Console.ReadLine();
            _billManager.ProcessLivingExpensePayment(roomNumber);
        }

        private void ProcessAccommodationBill()
        {
            Console.Write("Nhập mã số sinh viên: ");
            var studentId = Console.ReadLine();
            _billManager.ProcessAccommodationPayment(studentId);
        }
    }
}
﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using StudentInformation;
using System.Runtime.InteropServices.WindowsRuntime;
using ThongBao;
namespace RoomManagementSystem
{
    // Lớp Room để đại diện cho thông tin phòng
    public class Room
    {
        public string RoomNumber { get; set; }
        public int TotalBeds { get; set; }
        public int AvailableBeds { get; set; }
        public string Status { get; set; }

        // Constructor để khởi tạo phòng với thông tin ban đầu
        public Room(string roomNumber, int totalBeds, int availableBeds, string status)
        {
            RoomNumber = roomNumber;
            TotalBeds = totalBeds;
            AvailableBeds = availableBeds;
            Status = status;
        }

        // Cập nhật thông tin phòng
        public void UpdateRoomInfo(int totalBeds, int availableBeds, string status)
        {
            TotalBeds = totalBeds;
            AvailableBeds = availableBeds;
            Status = status;
        }

        // Tính số giường đã sử dụng
        public int UsedBeds()
        {
            return TotalBeds - AvailableBeds;
        }
    }

    // Lớp quản lý các thao tác liên quan đến phòng
    public class RoomOperations
    {
        public List<Room> roomList = new List<Room>();  // Danh sách các phòng
        public const string roomFile = "Room.txt";  // File lưu trữ thông tin phòng

        public void LoadRoomsFromFile()
        {
            try
            {
                if (File.Exists(roomFile))
                {
                    var lines = File.ReadLines(roomFile);
                    foreach (var line in lines)
                    {
                        var parts = line.Split(',');

                        // Kiểm tra xem dòng có đúng 4 phần không
                        if (parts.Length == 4)
                        {
                            try
                            {
                                string roomNumber = parts[0];
                                int totalBeds = int.Parse(parts[1]);
                                int availableBeds = int.Parse(parts[2]);
                                string status = parts[3];

                                // Tạo phòng và thêm vào danh sách
                                Room room = new Room(roomNumber, totalBeds, availableBeds, status);
                                roomList.Add(room);
                            }
                            catch (FormatException ex)
                            {
                                Console.WriteLine($"Lỗi định dạng trong dòng: {line}. Lỗi: {ex.Message}");
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Dòng dữ liệu không hợp lệ: {line}");
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"Không tìm thấy tệp: {roomFile}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi đọc phòng từ file: " + ex.Message);
            }
        }


        // Thêm phòng mới và lưu thông tin vào file
        public void AddRoom(Room room)
        {
            // Kiểm tra nếu phòng đã tồn tại
            if (IsRoomExist(room.RoomNumber))
            {
                Console.WriteLine("Số phòng đã tồn tại. Vui lòng chọn số phòng khác.");
            }
            else
            {
                roomList.Add(room);
                SaveRoomToFile(room);  // Lưu phòng vào file ngay sau khi thêm
                Console.WriteLine("Đã thêm phòng thành công.");
            }
        }

        // Lưu thông tin phòng vào file Room.txt
        public void SaveRoomToFile(Room room)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(roomFile, true))
                {
                    // Lưu thông tin phòng dưới dạng chuỗi phân cách bởi dấu phẩy
                    sw.WriteLine($"{room.RoomNumber},{room.TotalBeds},{room.AvailableBeds},{room.Status}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi lưu phòng vào file: " + ex.Message);
            }
        }

        // Lưu lại tất cả các phòng vào file (sau khi cập nhật hoặc xóa phòng)
        public void SaveAllRoomsToFile()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(roomFile, false)) // Ghi đè lên file cũ
                {
                    foreach (var room in roomList)
                    {
                        sw.WriteLine($"{room.RoomNumber},{room.TotalBeds},{room.AvailableBeds},{room.Status}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi lưu danh sách phòng vào file: " + ex.Message);
            }
        }

        // Hiển thị danh sách phòng
        public void DisplayRoomList()
        {
            if (roomList.Count == 0)
            {
                Console.WriteLine("Chưa có phòng nào được tạo.");
                return;
            }

            Console.WriteLine("------------------------------------------------------------------------------------");
            Console.WriteLine("| STT | Số phòng      | Tổng số giường | Giường trống  | Giường đã sử dụng | Ghi chú  ");
            Console.WriteLine("------------------------------------------------------------------------------------");

            int index = 1;
            foreach (var room in roomList.OrderBy(r => r.AvailableBeds))
            {
                Console.WriteLine($"| {index,-3} | {room.RoomNumber,-11} | {room.TotalBeds,-15} | {room.AvailableBeds,-12} | {room.UsedBeds(),-17} | {room.Status,-18} ");
                index++;
            }

            Console.WriteLine("------------------------------------------------------------------------------------");
        }

        // Kiểm tra xem phòng đã tồn tại hay chưa
        public bool IsRoomExist(string roomNumber)
        {
            return roomList.Any(r => r.RoomNumber == roomNumber);
        }

        // Cập nhật thông tin phòng
        public void UpdateRoom(string roomNumber, int totalBeds, int availableBeds, string status)
        {
            Room room = roomList.FirstOrDefault(r => r.RoomNumber == roomNumber);
            if (room != null)
            {
                room.UpdateRoomInfo(totalBeds, availableBeds, status);
                SaveAllRoomsToFile();  // Cập nhật lại file sau khi thay đổi thông tin phòng
                Console.WriteLine("Đã cập nhật thông tin phòng.");
            }
            else
            {
                Console.WriteLine("Phòng không tồn tại.");
            }
        }

        // Xóa phòng khỏi danh sách và file
        public void RemoveRoom(string roomNumber)
        {
            Room roomToRemove = roomList.FirstOrDefault(r => r.RoomNumber == roomNumber);
            if (roomToRemove != null)
            {
                roomList.Remove(roomToRemove);
                SaveAllRoomsToFile();  // Cập nhật lại file sau khi xóa phòng
                Console.WriteLine("Đã xóa phòng thành công.");
            }
            else
            {
                Console.WriteLine("Không tìm thấy phòng để xóa.");
            }
        }
    }

    // Lớp Menu quản lý phòng
    public static class RoomOperationsMenu
    {
        public static void RoomManagementMenu()
        {
            RoomOperations roomOperations = new RoomOperations();
            roomOperations.LoadRoomsFromFile();  // Nạp phòng từ file khi bắt đầu

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Menu quản lý phòng:");
                Console.WriteLine("1. Thêm phòng");
                Console.WriteLine("2. Xóa phòng");
                Console.WriteLine("3. Cập nhật thông tin phòng");
                Console.WriteLine("4. Hiển thị danh sách phòng");
                Console.WriteLine("5. Quay lại");
                Console.Write("Chọn chức năng: ");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập số từ 1 đến 5.");
                    Console.ReadKey();
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        // Thêm phòng
                        Console.Write("Nhập số phòng: ");
                        string roomNumberAdd = Console.ReadLine();
                        Console.Write("Nhập tổng số giường: ");
                        int totalBedsAdd = int.Parse(Console.ReadLine());
                        Console.Write("Nhập giường trống: ");
                        int availableBedsAdd = int.Parse(Console.ReadLine());
                        Console.Write("Nhập trạng thái phòng: ");
                        string statusAdd = Console.ReadLine();

                        Room roomAdd = new Room(roomNumberAdd, totalBedsAdd, availableBedsAdd, statusAdd);
                        roomOperations.AddRoom(roomAdd);
                        break;

                    case 2:
                        // Xóa phòng
                        Console.Write("Nhập số phòng cần xóa: ");
                        string roomNumberRemove = Console.ReadLine();
                        roomOperations.RemoveRoom(roomNumberRemove);  // Xóa phòng
                        break;

                    case 3:
                        // Cập nhật phòng
                        Console.Write("Nhập số phòng cần cập nhật: ");
                        string roomNumberUpdate = Console.ReadLine();
                        if (!roomOperations.IsRoomExist(roomNumberUpdate)) // Kiểm tra phòng tồn tại
                        {
                            Console.WriteLine("Số phòng không tồn tại.");
                            break;
                        }

                        Console.Write("Nhập tổng số giường: ");
                        int totalBedsUpdate = int.Parse(Console.ReadLine());
                        Console.Write("Nhập giường trống: ");
                        int availableBedsUpdate = int.Parse(Console.ReadLine());
                        Console.Write("Nhập trạng thái phòng: ");
                        string statusUpdate = Console.ReadLine();

                        roomOperations.UpdateRoom(roomNumberUpdate, totalBedsUpdate, availableBedsUpdate, statusUpdate); // Cập nhật thông tin phòng
                        break;

                    case 4:
                        // Hiển thị danh sách phòng
                        roomOperations.DisplayRoomList();
                        break;

                    case 5:
                        return; // Quay lại menu chính

                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ.");
                        break;
                }

                Console.WriteLine("Nhấn phím bất kỳ để tiếp tục...");
                Console.ReadKey();
            }
        }
    }
    // Thong tin sinh vien trong mot phong
    public class StudentInRoom
    {
        public string StudentName { get; set; }
        public string StudentId { get; set; }

        public StudentInRoom(string name, string id)
        {
            StudentName = name;
            StudentId = id;
        }
    }

    public class RoomManagement
    {
        private const string STUDENT_ROOMS_FOLDER = "StudentInRooms";
        private Dictionary<string, List<StudentInRoom>> roomStudents;

        public RoomManagement()
        {
            roomStudents = new Dictionary<string, List<StudentInRoom>>();
            InitializeStudentRoomsFolder();
            LoadAllRoomData();
        }

        private void InitializeStudentRoomsFolder()
        {
            if (!Directory.Exists(STUDENT_ROOMS_FOLDER))
            {
                Directory.CreateDirectory(STUDENT_ROOMS_FOLDER);
            }
        }

        private void LoadAllRoomData()
        {
            string[] files = Directory.GetFiles(STUDENT_ROOMS_FOLDER, "*.txt");
            foreach (string file in files)
            {
                string roomNumber = Path.GetFileNameWithoutExtension(file);
                roomStudents[roomNumber] = LoadRoomStudents(roomNumber);
            }
        }

        private List<StudentInRoom> LoadRoomStudents(string roomNumber)
        {
            List<StudentInRoom> students = new List<StudentInRoom>();
            string filePath = Path.Combine(STUDENT_ROOMS_FOLDER, $"{roomNumber}.txt");

            if (File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length == 2)
                    {
                        students.Add(new StudentInRoom(parts[0], parts[1]));
                    }
                }
            }

            return students;
        }

        private void SaveRoomStudents(string roomNumber)
        {
            if (roomStudents.ContainsKey(roomNumber))     
            {
                string filePath = Path.Combine(STUDENT_ROOMS_FOLDER, $"{roomNumber}.txt");
                var lines = roomStudents[roomNumber].Select(s => $"{s.StudentName},{s.StudentId}");
                File.WriteAllLines(filePath, lines);
            }
        }

        public List<StudentInRoom> GetStudentsInRoom(string roomNumber)
        {
            if (!roomStudents.ContainsKey(roomNumber))
            {
                return new List<StudentInRoom>();
            }

            return roomStudents[roomNumber];
        }

        public bool IsStudentInAnyRoom(string studentId)
        {
            foreach (var roomList in roomStudents.Values)
            {
                foreach (var student in roomList)
                {
                    if (student.StudentId == studentId)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private bool solve(string roomNumber)
        {
            string filePath = "Room.txt";
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Tệp không tồn tại.");
                return false;
            }

            var lines = File.ReadAllLines(filePath).ToList();

            for (int i = 0; i < lines.Count; i++)
            {
                string[] parts = lines[i].Split(',');
                if (parts[0].Equals(roomNumber))
                {
                    if (int.TryParse(parts[2].Trim(), out int availableBeds))
                    {
                        if (availableBeds == 0)
                        {
                            return false;
                        }

                        availableBeds--;
                        parts[2] = availableBeds.ToString();

                        if (availableBeds == 0)
                        {
                            parts[3] = "FULL";
                        }

                        lines[i] = string.Join(",", parts);
                        File.WriteAllLines(filePath, lines);
                        return true;
                    }
                }
            }
            return false;
        }


        public bool RegisterStudent(string roomNumber, string studentName, string studentId)
        {
            if (!solve(roomNumber)) return false;

            if (!roomStudents.ContainsKey(roomNumber))
            {
                roomStudents[roomNumber] = new List<StudentInRoom>();
            }

            var student = new StudentInRoom(studentName, studentId);
            roomStudents[roomNumber].Add(student);
            SaveRoomStudents(roomNumber);

            return true;
        }

        private void solve2(string fromRoom)
        {
            string filePath = "Room.txt";
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Tệp không tồn tại.");
                return;
            }

            var lines = File.ReadAllLines(filePath).ToList();

            for (int i = 0; i < lines.Count; i++)
            {
                string[] parts = lines[i].Split(',');
                if (parts[0].Equals(fromRoom))
                {
                    if (int.TryParse(parts[2].Trim(), out int availableBeds))
                    {
                        
                        availableBeds += 1;
                        parts[2] = availableBeds.ToString();
                        if (parts[2] != "0")
                        {
                            parts[3] = "NOT FULL";
                        }
                        lines[i] = string.Join(",", parts);
                        File.WriteAllLines(filePath, lines);
                    }
                }
            }
        }

        public bool TransferStudent(string fromRoom, string toRoom, string studentId)
        {
            // Tìm sinh viên trong phòng hiện tại
            if (!roomStudents.ContainsKey(fromRoom))
            {
                Console.WriteLine($"Không tìm thấy phòng {fromRoom}");
                return false;
            }

            var student = roomStudents[fromRoom].FirstOrDefault(s => s.StudentId == studentId);
            if (student == null)
            {
                Console.WriteLine($"Không tìm thấy sinh viên {studentId} trong phòng {fromRoom}");
                return false;
            }
            if (!solve(toRoom)) return false;
            solve2(fromRoom);
            // Chuyển sinh viên sang phòng mới
            if (!roomStudents.ContainsKey(toRoom))
            {
                roomStudents[toRoom] = new List<StudentInRoom>();
            }

            roomStudents[fromRoom].Remove(student);
            roomStudents[toRoom].Add(student);

            // Lưu thay đổi
            SaveRoomStudents(fromRoom);
            SaveRoomStudents(toRoom);

            return true;
        }

        public void DisplayRoomStatus(string roomNumber)
        {
            var students = GetStudentsInRoom(roomNumber);

            Console.WriteLine($"\nThông tin phòng {roomNumber}:");
            Console.WriteLine($"Số sinh viên hiện tại: {students.Count}");
            Console.WriteLine("Danh sách sinh viên:");
            Console.WriteLine(new string('-', 50));
            Console.WriteLine($"{"Họ tên",-30}{"Mã sinh viên",-20}");
            Console.WriteLine(new string('-', 50)); 

            foreach (var student in students)
            {
                Console.WriteLine($"{student.StudentName,-30}{student.StudentId,-20}");
            }
            Console.WriteLine(new string('-', 50));
        }
    }
}
﻿using System;
using System.IO;
using System.Linq;
using StudentInformation;
using DisplayStudentMenu;
using DisplayMenuManagement;

namespace AccountManagement
{
    public static class AccountManager
    {
        private static string accountFile = "Account.txt";
        public static string CurrentUsername { get; private set; }

        public static void InitializeAdminAccount()
        {
            if (!File.Exists(accountFile))
            {
                using (StreamWriter sw = new StreamWriter(accountFile, true))
                {
                    sw.WriteLine("admin,123");
                }
            }
        }

        public static void Login()
        {
            while (true)
            {
                Console.Clear();
                Console.Write("Nhập tài khoản: ");
                string username = Console.ReadLine();
                Console.Write("Nhập mật khẩu: ");
                string password = Console.ReadLine();

                if (CheckAccount(username, password))
                {
                    CurrentUsername = username;
                    Console.WriteLine("Đăng nhập thành công!");
                    Console.ReadKey();

                    if (username == "admin" && password == "123")
                    {
                        Management.MenuManagement();
                        break;
                    }

                    if (!StudentManager.HasInformation(username))
                    {
                        Console.WriteLine("Vui lòng hoàn thành thông tin sinh viên của bạn.");
                        StudentManager.UpdateInformation(username);
                    }

                    StudentMenu.ShowMenu();
                    break;
                }
                else
                {
                    Console.WriteLine("Sai tài khoản hoặc mật khẩu.");
                    Console.WriteLine("[1] Nhập lại");
                    Console.WriteLine("[2] Quay lại");
                    if (int.TryParse(Console.ReadLine(), out int choice) && choice == 2)
                    {
                        break;
                    }
                }
            }
        }

        public static void Register()
        {
            Console.Clear();
            Console.Write("Nhập tài khoản (định dạng @student.hcmute.edu.vn): ");
            string username = Console.ReadLine();
            Console.Write("Nhập mật khẩu: ");
            string password = Console.ReadLine();

            if (username.EndsWith("@student.hcmute.edu.vn"))
            {
                if (IsAccountExist(username))
                {
                    Console.WriteLine("Tài khoản đã tồn tại. Vui lòng chọn tài khoản khác.");
                }
                else
                {
                    SaveAccount(username, password);
                    Console.WriteLine("Đăng ký thành công!");
                }
            }
            else
            {
                Console.WriteLine("Tài khoản không đúng định dạng. Vui lòng đăng ký tài khoản sinh viên.");
            }

            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }

        private static bool CheckAccount(string username, string password)
        {
            try
            {
                return File.ReadLines(accountFile)
                    .Any(line =>
                    {
                        var parts = line.Split(',');
                        return parts[0] == username && parts[1] == password;
                    });
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi đọc file: " + ex.Message);
                return false;
            }
        }

        private static bool IsAccountExist(string username)
        {
            try
            {
                return File.ReadLines(accountFile)
                    .Any(line => line.Split(',')[0] == username);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi đọc file: " + ex.Message);
                return false;
            }
        }

        private static void SaveAccount(string username, string password)
        {
            try
            {
                File.AppendAllText(accountFile, $"{username},{password}\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi lưu tài khoản: " + ex.Message);
            }
        }

        public static bool ConfirmExit()
        {
            Console.WriteLine("Bạn có chắc chắn muốn thoát? [Y/N]");
            return Console.ReadLine().Trim().ToUpper() == "Y";
        }
    }
}